<style type="text/css">
	fieldset{
		width: 100px;
	}
	#a{color: red;}
</style>
<?php
echo "<meta charset=utf-8>";
echo "<center>";
echo "<fieldset>";
echo "<h4 id=a>FALHA NA AUTENTICAÇÃO!</h4>";
echo "Usuário: <input type='text' name='login'></input>";
echo "<br>";
echo "<br>";
echo "Senha: <input type='password' name='senha'></input>";
echo "<br>";
echo "<br>";
echo "<input type='submit' name='ENVIAR'>";
echo "</fieldset>";
echo "</center>";
?>